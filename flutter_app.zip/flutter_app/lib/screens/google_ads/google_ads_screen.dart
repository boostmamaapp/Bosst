import 'package:flutter/material.dart';

class GoogleAdsScreen extends StatelessWidget {
  const GoogleAdsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text("Google Ads"),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Card(
              child: ListTile(
                leading: const Icon(Icons.ads_click, color: Colors.deepPurple),
                title: const Text("Google Ads Campaign"),
                subtitle: const Text("Create and manage your Google Ads campaign."),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              decoration: const InputDecoration(
                labelText: "Website URL",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 15),
            TextField(
              decoration: const InputDecoration(
                labelText: "Budget (৳)",
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 15),
            TextField(
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: "Campaign Details",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 50,
              child: ElevatedButton(
                onPressed: () {},
                child: const Text("Submit Campaign"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
