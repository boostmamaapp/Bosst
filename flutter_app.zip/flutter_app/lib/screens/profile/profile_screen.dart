import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text("My Profile"),
        backgroundColor: Colors.deepPurple,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [

          const CircleAvatar(
            radius: 50,
            child: Icon(Icons.person, size: 55),
          ),

          const SizedBox(height: 15),

          const Center(
            child: Text(
              "User Name",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          const SizedBox(height: 25),

          Card(
            child: ListTile(
              leading: const Icon(Icons.phone),
              title: const Text("Mobile"),
              subtitle: const Text("+8801XXXXXXXXX"),
            ),
          ),

          Card(
            child: ListTile(
              leading: const Icon(Icons.email),
              title: const Text("Email"),
              subtitle: const Text("user@email.com"),
            ),
          ),

          Card(
            child: ListTile(
              leading: const Icon(Icons.account_balance_wallet),
              title: const Text("Wallet Balance"),
              subtitle: const Text("৳0"),
            ),
          ),

          Card(
            child: ListTile(
              leading: const Icon(Icons.shopping_bag),
              title: const Text("Total Orders"),
              subtitle: const Text("0"),
            ),
          ),

          const SizedBox(height: 20),

          SizedBox(
            height: 50,
            child: ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.logout),
              label: const Text("Logout"),
            ),
          ),

        ],
      ),
    );
  }
}
