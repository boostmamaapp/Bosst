import 'package:flutter/material.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> methods = [
      {"title": "bKash", "icon": Icons.account_balance_wallet},
      {"title": "Nagad", "icon": Icons.account_balance_wallet},
      {"title": "Rocket", "icon": Icons.rocket_launch},
      {"title": "Binance Pay", "icon": Icons.currency_bitcoin},
      {"title": "USDT (TRC20)", "icon": Icons.currency_exchange},
      {"title": "USDT (BEP20)", "icon": Icons.currency_exchange},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Wallet"),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: const ListTile(
                leading: Icon(Icons.account_balance_wallet,
                    color: Colors.deepPurple),
                title: Text(
                  "Available Balance",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text("৳0.00"),
              ),
            ),
            const SizedBox(height: 20),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Deposit Methods",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: methods.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: ListTile(
                      leading: Icon(
                        methods[index]["icon"],
                        color: Colors.deepPurple,
                      ),
                      title: Text(methods[index]["title"]),
                      trailing: const Icon(Icons.arrow_forward_ios),
                      onTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              "${methods[index]["title"]} coming soon",
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}