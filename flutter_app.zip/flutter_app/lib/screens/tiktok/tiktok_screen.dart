import 'package:flutter/material.dart';

class TiktokScreen extends StatelessWidget {
  const TiktokScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("TikTok Services"),
        backgroundColor: Colors.deepPurple,
      ),
      body: const Center(
        child: Text(
          "TikTok Services Coming Soon",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
