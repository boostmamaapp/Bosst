import 'package:flutter/material.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> orders = [
      {
        "id": "#1001",
        "service": "Facebook Boost",
        "date": "25 Jul 2026",
        "amount": "৳500",
        "status": "Pending",
        "statusColor": Colors.orange,
      },
      {
        "id": "#1000",
        "service": "Google Ads",
        "date": "24 Jul 2026",
        "amount": "৳1200",
        "status": "Completed",
        "statusColor": Colors.green,
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("My Orders"),
        backgroundColor: Colors.deepPurple,
      ),
      body: orders.isEmpty
          ? const Center(
              child: Text(
                "No orders found",
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(12.0),
              child: ListView.builder(
                itemCount: orders.length,
                itemBuilder: (context, index) {
                  final order = orders[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(12),
                      leading: const CircleAvatar(
                        backgroundColor: Colors.deepPurple,
                        child: Icon(Icons.shopping_bag, color: Colors.white),
                      ),
                      title: Text(
                        "${order['service']} (${order['id']})",
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Padding(
                        padding: const EdgeInsets.only(top: 6.0),
                        child: Text("Date: ${order['date']}\nAmount: ${order['amount']}"),
                      ),
                      trailing: Chip(
                        label: Text(
                          order['status'],
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        backgroundColor: order['statusColor'],
                      ),
                    ),
                  );
                },
              ),
            ),
    );
  }
}
