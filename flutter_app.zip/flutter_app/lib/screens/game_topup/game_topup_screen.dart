import 'package:flutter/material.dart';

class GameTopupScreen extends StatelessWidget {
  const GameTopupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Game Top-up"),
        backgroundColor: Colors.deepPurple,
      ),
      body: const Center(
        child: Text(
          "Game Top-up Coming Soon",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
