import 'package:flutter/material.dart';
import 'user_management_screen.dart';
import 'order_management_screen.dart';
import 'wallet_management_screen.dart';
import 'service_management_screen.dart';
import 'statistics_screen.dart';
import 'api_sync_screen.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Boost Mama - Admin Dashboard"),
        backgroundColor: Colors.deepPurple,
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {},
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          children: [
            // ১. User Management Card
            _buildDashboardCard(
              context,
              title: "User Management",
              icon: Icons.people,
              color: Colors.blue,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const UserManagementScreen()),
                );
              },
            ),

            // ২. Order Management Card
            _buildDashboardCard(
              context,
              title: "Order Management",
              icon: Icons.shopping_bag,
              color: Colors.orange,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const OrderManagementScreen()),
                );
              },
            ),

            // ৩. Wallet & Payments Card
            _buildDashboardCard(
              context,
              title: "Wallet & Payments",
              icon: Icons.account_balance_wallet,
              color: Colors.green,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const WalletManagementScreen()),
                );
              },
            ),

            // ৪. Service Management Card
            _buildDashboardCard(
              context,
              title: "Service Management",
              icon: Icons.room_service,
              color: Colors.purple,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ServiceManagementScreen()),
                );
              },
            ),

            // ৫. Statistics Card
            _buildDashboardCard(
              context,
              title: "Statistics",
              icon: Icons.bar_chart,
              color: Colors.red,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const StatisticsScreen()),
                );
              },
            ),

            // ৬. Laravel API Sync Card
            _buildDashboardCard(
              context,
              title: "Laravel API Sync",
              icon: Icons.sync,
              color: Colors.teal,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ApiSyncScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardCard(
    BuildContext context, {
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: color.withOpacity(0.2),
                child: Icon(icon, size: 30, color: color),
              ),
              const SizedBox(height: 12),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
