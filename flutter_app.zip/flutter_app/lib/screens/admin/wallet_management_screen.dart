import 'package:flutter/material.dart';

class WalletManagementScreen extends StatefulWidget {
  const WalletManagementScreen({super.key});

  @override
  State<WalletManagementScreen> createState() => _WalletManagementScreenState();
}

class _WalletManagementScreenState extends State<WalletManagementScreen> {
  // ডেমো পেমেন্ট ও ওয়ালেট ডিপোজিট রিকোয়েস্ট ডেটা
  final List<Map<String, dynamic>> _deposits = [
    {"user": "রহিম উদ্দিন", "method": "bKash", "amount": "1000৳", "trxId": "TRX893241", "status": "Pending"},
    {"user": "করিম আহমেদ", "method": "Nagad", "amount": "500৳", "trxId": "NGD443120", "status": "Approved"},
    {"user": "সাজেদা বেগম", "method": "USDT", "amount": "\$20 (2400৳)", "trxId": "0x8f3c...1e9a", "status": "Pending"},
    {"user": "মিনহাজুল ইসলাম", "method": "Rocket", "amount": "300৳", "trxId": "RCK778219", "status": "Rejected"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Wallet & Payments Approval"),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ListView.builder(
          itemCount: _deposits.length,
          itemBuilder: (context, index) {
            final deposit = _deposits[index];
            String status = deposit['status'];

            Color statusColor = Colors.orange;
            if (status == 'Approved') statusColor = Colors.green;
            if (status == 'Rejected') statusColor = Colors.red;

            return Card(
              margin: const EdgeInsets.symmetric(vertical: 6),
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.green.withOpacity(0.2),
                  child: const Icon(Icons.account_balance_wallet, color: Colors.green),
                ),
                title: Text("${deposit['user']} (${deposit['method']})", style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text("Amount: ${deposit['amount']}\nTrxID: ${deposit['trxId']} | Status: $status"),
                isThreeLine: true,
                trailing: PopupMenuButton<String>(
                  onSelected: (value) {
                    setState(() {
                      deposit['status'] = value;
                    });
                  },
                  itemBuilder: (BuildContext context) => [
                    const PopupMenuItem(value: 'Pending', child: Text("⏳ Pending")),
                    const PopupMenuItem(value: 'Approved', child: Text("✅ Approve")),
                    const PopupMenuItem(value: 'Rejected', child: Text("❌ Reject", style: TextStyle(color: Colors.red))),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
