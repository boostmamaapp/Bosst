import 'package:flutter/material.dart';

class UserManagementScreen extends StatefulWidget {
  const UserManagementScreen({super.key});

  @override
  State<UserManagementScreen> createState() => _UserManagementScreenState();
}

class _UserManagementScreenState extends State<UserManagementScreen> {
  // ডেমো ইউজার ডেটা (পরে এটি ফায়ারবেস বা লারাভেল API থেকে আসবে)
  final List<Map<String, dynamic>> _users = [
    {"name": "রহিম উদ্দিন", "email": "rahim@gmail.com", "phone": "01711111111", "status": "Active", "balance": "500৳"},
    {"name": "করিম আহমেদ", "email": "karim@gmail.com", "phone": "01822222222", "status": "Blocked", "balance": "120৳"},
    {"name": "সাজেদা বেগম", "email": "sajeda@gmail.com", "phone": "01933333333", "status": "Active", "balance": "1500৳"},
    {"name": "মিনহাজুল ইসলাম", "email": "minhaj@gmail.com", "phone": "01544444444", "status": "Active", "balance": "350৳"},
  ];

  List<Map<String, dynamic>> _filteredUsers = [];
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _filteredUsers = _users;
  }

  // ইউজার সার্চ করার ফাংশন
  void _filterUsers(String query) {
    setState(() {
      _filteredUsers = _users.where((user) {
        final nameLower = user['name'].toLowerCase();
        final emailLower = user['email'].toLowerCase();
        final searchLower = query.toLowerCase();
        return nameLower.contains(searchLower) || emailLower.contains(searchLower);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("User Management"),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            // ১. Total Users কার্ড
            Card(
              elevation: 3,
              color: Colors.deepPurple.shade50,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.people, size: 36, color: Colors.deepPurple),
                        SizedBox(width: 12),
                        Text(
                          "Total Users",
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    Text(
                      "${_users.length}",
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.deepPurple),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // ২. Search Box
            TextField(
              controller: _searchController,
              onChanged: _filterUsers,
              decoration: InputDecoration(
                hintText: "Search by name or email...",
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                filled: true,
                fillColor: Colors.grey.shade100,
              ),
            ),
            const SizedBox(height: 12),

            // ৩. User List
            Expanded(
              child: _filteredUsers.isEmpty
                  ? const Center(child: Text("কোনো ইউজার পাওয়া যায়নি"))
                  : ListView.builder(
                      itemCount: _filteredUsers.length,
                      itemBuilder: (context, index) {
                        final user = _filteredUsers[index];
                        bool isActive = user['status'] == 'Active';

                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 6),
                          elevation: 2,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor: Colors.deepPurple.withOpacity(0.2),
                              child: Text(
                                user['name'][0],
                                style: const TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                              ),
                            ),
                            title: Text(user['name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Text("${user['email']}\nBalance: ${user['balance']}"),
                            isThreeLine: true,
                            trailing: PopupMenuButton<String>(
                              onSelected: (value) {
                                if (value == 'view') {
                                  _showActionDialog(context, "View Profile", "${user['name']} এর প্রোফাইল দেখা হচ্ছে।");
                                } else if (value == 'edit') {
                                  _showActionDialog(context, "Edit User", "${user['name']} এর তথ্য সম্পাদনা করুন।");
                                } else if (value == 'block') {
                                  setState(() {
                                    user['status'] = isActive ? 'Blocked' : 'Active';
                                  });
                                } else if (value == 'delete') {
                                  setState(() {
                                    _users.remove(user);
                                    _filterUsers(_searchController.text);
                                  });
                                }
                              },
                              itemBuilder: (BuildContext context) => [
                                const PopupMenuItem(value: 'view', child: Text("👤 View Profile")),
                                const PopupMenuItem(value: 'edit', child: Text("✏️ Edit User")),
                                PopupMenuItem(
                                  value: 'block', 
                                  child: Text(isActive ? "🚫 Block User" : "✅ Unblock User")
                                ),
                                const PopupMenuItem(value: 'delete', child: Text("🗑️ Delete User", style: TextStyle(color: Colors.red))),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // অ্যাকশন নোটিফিকেশন দেখানোর ডায়ালগ
  void _showActionDialog(BuildContext context, String title, String message) {
    showDialog(
      context: FlutterLogo().runtimeType == Container ? context : context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("ঠিক আছে"),
          ),
        ],
      ),
    );
  }
}
