import 'package:flutter/material.dart';

class StatisticsScreen extends StatelessWidget {
  const StatisticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Dashboard Statistics"),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ListView(
          children: [
            // মোট আয় বা রেভিনিউ কার্ড
            _buildStatCard(
              title: "Total Revenue",
              value: "45,250 ৳",
              icon: Icons.monetization_on,
              color: Colors.green,
            ),
            const SizedBox(height: 10),

            // মোট সফল অর্ডার
            _buildStatCard(
              title: "Completed Orders",
              value: "1,240",
              icon: Icons.check_circle,
              color: Colors.blue,
            ),
            const SizedBox(height: 10),

            // পেন্ডিং অর্ডার
            _buildStatCard(
              title: "Pending Orders",
              value: "35",
              icon: Icons.hourglass_empty,
              color: Colors.orange,
            ),
            const SizedBox(height: 10),

            // মোট রেজিস্টার্ড ইউজার
            _buildStatCard(
              title: "Total Registered Users",
              value: "850",
              icon: Icons.people_alt,
              color: Colors.purple,
            ),
            const SizedBox(height: 10),

            // অ্যাক্টিভ সার্ভিস সংখ্যা
            _buildStatCard(
              title: "Active Services",
              value: "18",
              icon: Icons.room_service,
              color: Colors.teal,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 24,
                  backgroundColor: color.withOpacity(0.2),
                  child: Icon(icon, color: color, size: 28),
                ),
                const SizedBox(width: 16),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            Text(
              value,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
