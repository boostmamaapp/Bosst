import 'package:flutter/material.dart';

class ApiSyncScreen extends StatefulWidget {
  const ApiSyncScreen({super.key});

  @override
  State<ApiSyncScreen> createState() => _ApiSyncScreenState();
}

class _ApiSyncScreenState extends State<ApiSyncScreen> {
  bool _isSyncing = false;
  String _syncStatus = "Not Connected Yet";
  final TextEditingController _urlController = TextEditingController(text: "https://your-laravel-api.com/api/v1");

  void _startSync() {
    setState(() {
      _isSyncing = true;
      _syncStatus = "Connecting to Laravel API...";
    });

    // ডেমো সিঙ্ক প্রসেস (পরে এখানে আসল HTTP রিকোয়েস্ট বসবে)
    Future.delayed(const Duration(seconds: 2), () {
      setState(() {
        _isSyncing = false;
        _syncStatus = "Successfully Connected & Synced! ✅";
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Laravel API Sync"),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              "Backend API Configuration",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _urlController,
              decoration: InputDecoration(
                labelText: "API Base URL",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                prefixIcon: const Icon(Icons.link),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _isSyncing ? null : _startSync,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              icon: _isSyncing 
                  ? const SizedBox(
                      width: 20, 
                      height: 20, 
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                    )
                  : const Icon(Icons.sync, color: Colors.white),
              label: Text(
                _isSyncing ? "Syncing Data..." : "Test & Sync Now",
                style: const TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
            const SizedBox(height: 30),
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    const Text(
                      "Sync Status",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      _syncStatus,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: _syncStatus.contains("Successfully") ? Colors.green : Colors.orange,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
