import 'package:flutter/material.dart';

class OrderManagementScreen extends StatefulWidget {
  const OrderManagementScreen({super.key});

  @override
  State<OrderManagementScreen> createState() => _OrderManagementScreenState();
}

class _OrderManagementScreenState extends State<OrderManagementScreen> {
  // ডেমো অর্ডার ডেটা (পরে এটি ফায়ারবেস বা লারাভেল API থেকে আসবে)
  final List<Map<String, dynamic>> _orders = [
    {"orderId": "#BM1001", "service": "Facebook Page Boost", "user": "রহিম উদ্দিন", "amount": "500৳", "status": "Pending"},
    {"orderId": "#BM1002", "service": "YouTube Subscribers", "user": "করিম আহমেদ", "amount": "1200৳", "status": "Processing"},
    {"orderId": "#BM1003", "service": "TikTok Followers", "user": "সাজেদা বেগম", "amount": "300৳", "status": "Completed"},
    {"orderId": "#BM1004", "service": "Google Ads Campaign", "user": "মিনহাজুল ইসলাম", "amount": "2500৳", "status": "Cancelled"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Order Management"),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ListView.builder(
          itemCount: _orders.length,
          itemBuilder: (context, index) {
            final order = _orders[index];
            String status = order['status'];
            
            // স্ট্যাটাস অনুযায়ী কালার সেট করা
            Color statusColor = Colors.orange;
            if (status == 'Completed') statusColor = Colors.green;
            if (status == 'Cancelled') statusColor = Colors.red;
            if (status == 'Processing') statusColor = Colors.blue;

            return Card(
              margin: const EdgeInsets.symmetric(vertical: 6),
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.deepPurple.withOpacity(0.2),
                  child: const Icon(Icons.shopping_bag, color: Colors.deepPurple),
                ),
                title: Text("${order['orderId']} - ${order['service']}", style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text("User: ${order['user']}\nAmount: ${order['amount']} | Status: $status"),
                isThreeLine: true,
                trailing: PopupMenuButton<String>(
                  onSelected: (value) {
                    setState(() {
                      order['status'] = value;
                    });
                  },
                  itemBuilder: (BuildContext context) => [
                    const PopupMenuItem(value: 'Pending', child: Text("⏳ Pending")),
                    const PopupMenuItem(value: 'Processing', child: Text("🔄 Processing")),
                    const PopupMenuItem(value: 'Completed', child: Text("✅ Completed")),
                    const PopupMenuItem(value: 'Cancelled', child: Text("❌ Cancelled", style: TextStyle(color: Colors.red))),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
