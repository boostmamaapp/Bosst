import 'package:flutter/material.dart';

class AddMoneyScreen extends StatefulWidget {
  const AddMoneyScreen({super.key});

  @override
  State<AddMoneyScreen> createState() => _AddMoneyScreenState();
}

class _AddMoneyScreenState extends State<AddMoneyScreen> {
  String _selectedMethod = "bKash";
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _trxIdController = TextEditingController();

  final List<String> _methods = ["bKash", "Nagad", "Rocket", "USDT (Binance)"];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add Money to Wallet"),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            const Text(
              "Select Payment Method",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            
            // পেমেন্ট মেথড চয়েস করার অপশন
            DropdownButtonFormField<String>(
              value: _selectedMethod,
              decoration: InputDecoration(
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                filled: true,
                fillColor: Colors.grey.shade100,
              ),
              items: _methods.map((method) {
                return DropdownMenuItem(
                  value: method,
                  child: Text(method, style: const TextStyle(fontWeight: FontWeight.bold)),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedMethod = value!;
                });
              },
            ),
            const SizedBox(height: 20),

            // পেমেন্ট গাইডলাইন কার্ড
            Card(
              color: Colors.deepPurple.shade50,
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Payment Instructions for $_selectedMethod:",
                      style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.deepPurple),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "1. Send money to our Personal Number: 01700000000\n"
                      "2. Copy the Transaction ID (TrxID) after payment.\n"
                      "3. Enter the exact amount and TrxID below.",
                      style: TextStyle(fontSize: 13, height: 1.4),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // অ্যামাউন্ট ইনপুট
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: "Amount (BDT / USD)",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                prefixIcon: const Icon(Icons.money),
              ),
            ),
            const SizedBox(height: 15),

            // ট্রানজ্যাকশন আইডি ইনপুট
            TextField(
              controller: _trxIdController,
              decoration: InputDecoration(
                labelText: "Transaction ID (TrxID)",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                prefixIcon: const Icon(Icons.receipt_long),
              ),
            ),
            const SizedBox(height: 25),

            // সাবমিট বাটন
            ElevatedButton(
              onPressed: () {
                // পেমেন্ট সাবমিট করার লজিক
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Deposit request submitted successfully! Pending approval. ⏳")),
                );
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text(
                "Submit Deposit Request",
                style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
