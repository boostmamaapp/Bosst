import 'package:flutter/material.dart';
import 'add_money_screen.dart';
import 'my_orders_screen.dart';

class UserDashboardScreen extends StatefulWidget {
  const UserDashboardScreen({super.key});

  @override
  State<UserDashboardScreen> createState() => _UserDashboardScreenState();
}

class _UserDashboardScreenState extends State<UserDashboardScreen> {
  // ডেমো সার্ভিস ক্যাটাগরি
  final List<Map<String, dynamic>> _services = [
    {"name": "Facebook Page Boost", "icon": Icons.facebook, "color": Colors.blue, "price": "500৳ / 1k"},
    {"name": "YouTube Subscribers", "icon": Icons.subscriptions, "color": Colors.red, "price": "1200৳ / 1k"},
    {"name": "TikTok Followers", "icon": Icons.video_collection, "color": Colors.black, "price": "300৳ / 1k"},
    {"name": "Google Ads Campaign", "icon": Icons.search, "color": Colors.green, "price": "2500৳ budget"},
    {"name": "Telegram Members", "icon": Icons.telegram, "color": Colors.lightBlue, "price": "400৳ / 1k"},
    {"name": "Game Top-up (Free Fire/PUBG)", "icon": Icons.sports_esports, "color": Colors.orange, "price": "Varies"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Boost Mama - User Dashboard"),
        backgroundColor: Colors.deepPurple,
        actions: [
          // মাই অর্ডার্স পেজে যাওয়ার বাটন
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: "My Orders",
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const MyOrdersScreen()),
              );
            },
          ),
          // ওয়ালেট বাটন
          IconButton(
            icon: const Icon(Icons.account_balance_wallet),
            tooltip: "Add Money",
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AddMoneyScreen()),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ১. ওয়ালেট ব্যালেন্স কার্ড
            Card(
              elevation: 4,
              color: Colors.deepPurple.shade50,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Available Balance", style: TextStyle(fontSize: 14, color: Colors.grey)),
                        SizedBox(height: 4),
                        Text("1,250.00 ৳", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.deepPurple)),
                      ],
                    ),
                    ElevatedButton.icon(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const AddMoneyScreen()),
                        );
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
                      icon: const Icon(Icons.add, color: Colors.white),
                      label: const Text("Add Money", style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            
            // নিচের দিকে মাই অর্ডার্স দেখার শর্টকাট বাটন
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const MyOrdersScreen()),
                  );
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.deepPurple,
                  side: const BorderSide(color: Colors.deepPurple),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                icon: const Icon(Icons.list_alt),
                label: const Text("View My Order History", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 16),

            const Text(
              "Available Services",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),

            // ২. সার্ভিস লিস্ট গ্রিড
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.1,
                ),
                itemCount: _services.length,
                itemBuilder: (context, index) {
                  final service = _services[index];
                  return Card(
                    elevation: 3,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: InkWell(
                      onTap: () {
                        _showOrderDialog(context, service['name'], service['price']);
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircleAvatar(
                              radius: 24,
                              backgroundColor: service['color'].withOpacity(0.2),
                              child: Icon(service['icon'], color: service['color'], size: 28),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              service['name'],
                              textAlign: TextAlign.center,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              service['price'],
                              style: const TextStyle(fontSize: 11, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // অর্ডার করার ডায়ালগ বক্স
  void _showOrderDialog(BuildContext context, String serviceName, String price) {
    final TextEditingController linkController = TextEditingController();
    final TextEditingController quantityController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Order: $serviceName"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("Rate: $price", style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.deepPurple)),
            const SizedBox(height: 12),
            TextField(
              controller: linkController,
              decoration: const InputDecoration(
                labelText: "Target Link (Page/Video/Profile)",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: quantityController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Quantity",
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Order placed successfully! ✅")),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
            child: const Text("Submit Order", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}
