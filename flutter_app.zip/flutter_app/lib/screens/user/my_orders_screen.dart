import 'package:flutter/material.dart';

class MyOrdersScreen extends StatelessWidget {
  const MyOrdersScreen({super.key});

  // ডেমো অর্ডার হিস্টোরি ডেটা
  final List<Map<String, dynamic>> _myOrders = const [
    {"service": "Facebook Page Boost", "link": "fb.com/page1", "qty": "1000", "amount": "500৳", "status": "Pending"},
    {"service": "YouTube Subscribers", "link": "youtube.com/c/channel", "qty": "500", "amount": "600৳", "status": "Processing"},
    {"service": "TikTok Followers", "link": "tiktok.com/@user", "qty": "2000", "amount": "600৳", "status": "Completed"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Order History"),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ListView.builder(
          itemCount: _myOrders.length,
          itemBuilder: (context, index) {
            final order = _myOrders[index];
            String status = order['status']!;

            Color statusColor = Colors.orange;
            if (status == 'Completed') statusColor = Colors.green;
            if (status == 'Processing') statusColor = Colors.blue;

            return Card(
              margin: const EdgeInsets.symmetric(vertical: 6),
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.deepPurple.withOpacity(0.2),
                  child: const Icon(Icons.history, color: Colors.deepPurple),
                ),
                title: Text(order['service']!, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text("Link: ${order['link']}\nQty: ${order['qty']} | Cost: ${order['amount']}"),
                isThreeLine: true,
                trailing: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    status,
                    style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 12),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
