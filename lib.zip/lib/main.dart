import 'package:flutter/material.dart';
import 'screens/auth/login_screen.dart';

void main() {
  runApp(const BoostMamaApp());
}

class BoostMamaApp extends StatelessWidget {
  const BoostMamaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Boost Mama',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        useMaterial3: true,
      ),
      home: const LoginScreen(), // সবার আগে লগইন স্ক্রিন দেখাবে
    );
  }
}
